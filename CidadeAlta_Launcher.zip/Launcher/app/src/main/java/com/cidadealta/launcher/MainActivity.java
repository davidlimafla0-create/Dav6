package com.cidadealta.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    LinearLayout root;
    final int bg = Color.rgb(10, 15, 25);
    final int panel = Color.rgb(22, 31, 47);
    final int accent = Color.rgb(26, 125, 190);

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    TextView label(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER);
        return t;
    }

    GradientDrawable shape(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radiusDp));
        return d;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(shape(accent, 22));
        return b;
    }

    EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint);
        e.setTextColor(Color.WHITE); e.setHintTextColor(0xffaab4c3);
        e.setBackground(shape(panel, 16)); e.setPadding(dp(16), dp(4), dp(16), dp(4));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    LinearLayout.LayoutParams wide() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(360), dp(52));
        p.setMargins(0, dp(6), 0, dp(6));
        return p;
    }

    void newScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(12), dp(24), dp(12));
        root.setBackgroundColor(bg);
        setContentView(root);
    }

    void loadingScreen() {
        newScreen();
        TextView title = label("CIDADE ALTA", 34);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        root.addView(label("Carregando...", 16));
        root.addView(new ProgressBar(this));
        root.postDelayed(this::homeScreen, 1500);
    }

    void homeScreen() {
        newScreen();
        TextView title = label("CIDADE ALTA", 34);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        root.addView(label("ROLEPLAY • MOBILE", 14));
        root.addView(new Space(this), new LinearLayout.LayoutParams(1, dp(16)));
        Button enter = button("ENTRAR");
        Button create = button("CRIAR CONTA");
        root.addView(enter, wide());
        root.addView(create, wide());
        enter.setOnClickListener(v -> formScreen(false));
        create.setOnClickListener(v -> formScreen(true));
    }

    void formScreen(boolean create) {
        newScreen();
        root.addView(label(create ? "CRIAR CONTA" : "ENTRAR", 26));
        EditText user = field("Nome de usuário", false);
        EditText pass = field("Senha", true);
        root.addView(user, wide());
        root.addView(pass, wide());
        Button action = button(create ? "CADASTRAR" : "CONTINUAR");
        Button back = button("VOLTAR");
        root.addView(action, wide());
        root.addView(back, wide());
        action.setOnClickListener(v -> {
            if (user.getText().length() == 0 || pass.getText().length() == 0) {
                Toast.makeText(this, "Preencha usuário e senha", Toast.LENGTH_SHORT).show();
                return;
            }
            // Demonstração: ainda não há servidor de contas conectado.
            serverScreen();
        });
        back.setOnClickListener(v -> homeScreen());
    }

    void serverScreen() {
        newScreen();
        root.addView(label("SELECIONE O SERVIDOR", 20));
        TextView server = label("Cidade Alta • Em configuração", 18);
        server.setPadding(dp(12), dp(14), dp(12), dp(14));
        server.setBackground(shape(panel, 18));
        root.addView(server, wide());
        Button play = button("PLAY");
        Button back = button("VOLTAR");
        root.addView(play, wide());
        root.addView(back, wide());
        play.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Em breve")
            .setMessage("O launcher está pronto. Falta conectar o servidor e o jogo.")
            .setPositiveButton("OK", null).show());
        back.setOnClickListener(v -> homeScreen());
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        loadingScreen();
    }
}
